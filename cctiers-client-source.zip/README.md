# CcTiers Client

Fabric client mod for Minecraft 1.21.11 by AyushXDP. Client-side only, display only.

- **Right Shift** (or `/ccclient`) opens the card menu. Left-click a card to enable/disable it; right-click (or Edit) opens its settings.
- Cards: FPS, Coordinates, Biome, Direction, Clock, Memory, TPS, Ping, Day counter, Speed, CPS, Combo, Reach, Keystrokes, Motion Blur (locked resource pack, same engine as the standalone Motion Blur mod), CcTiers Tag.
- HUD cards are white text on black by default; every card can change text color, background color/opacity or turn the background off.
- **CcTiers Tag**: CcTiers logo + tier next to nametags (and tab list), on the Left or Right.
- Scenic main menu with your CCTiers tiers (API: https://api.hypen9.qzz.io/players).
- Config: `config/ccclient.json`.
