package com.ccclient.ui;

import com.ccclient.core.Cfg;
import com.ccclient.core.Mod;
import com.ccclient.hud.Hud;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Drag any HUD element to move it. Right-click an element to put it back. */
public class HudEditorScreen extends Screen {
    private final Screen parent;
    private final Pad pad = new Pad();
    private String dragging = null;
    private int offX, offY;

    public HudEditorScreen(Screen parent) {
        super(Text.literal("HUD layout"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        pad.sync(this.client.getWindow().getHandle());
        Hud.preview = true;
    }

    @Override
    public void removed() {
        Hud.preview = false;
        Cfg.save();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        Hud.preview = false;
        Cfg.save();
        this.client.setScreen(parent);
    }

    private String topAt(int mx, int my) {
        List<String> ids = new ArrayList<>(Hud.bounds.keySet());
        for (int i = ids.size() - 1; i >= 0; i--) {
            int[] b = Hud.bounds.get(ids.get(i));
            if (b != null && Gfx.inside(mx, my, b[0], b[1], b[2], b[3])) return ids.get(i);
        }
        return null;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        pad.poll(this.client.getWindow().getHandle());
        ctx.fill(0, 0, this.width, this.height, 0x44000000);

        String hover = dragging != null ? dragging : topAt(mx, my);
        for (String id : Hud.bounds.keySet()) {
            int[] b = Hud.bounds.get(id);
            if (b == null) continue;
            Gfx.outline(ctx, b[0] - 1, b[1] - 1, b[2] + 2, b[3] + 2, id.equals(hover) ? Gfx.GOLD_LIGHT : Gfx.GOLD_DARK);
        }
        if (hover != null) {
            Mod m = Mod.get(hover);
            int[] b = Hud.bounds.get(hover);
            if (m != null && b != null) {
                int ty = b[1] > 12 ? b[1] - 11 : b[1] + b[3] + 2;
                Gfx.text(ctx, this.textRenderer, m.name, b[0], ty, Gfx.GOLD_LIGHT);
            }
        }

        if (pad.lPress()) {
            String id = topAt(mx, my);
            if (id != null) {
                dragging = id;
                int[] b = Hud.bounds.get(id);
                offX = mx - b[0];
                offY = my - b[1];
            }
        }
        if (dragging != null && pad.l) {
            Cfg.setPos(dragging, (mx - offX) / (float) this.width, (my - offY) / (float) this.height);
        }
        if (pad.lRelease() && dragging != null) {
            dragging = null;
            Cfg.save();
        }
        if (pad.rPress()) {
            String id = topAt(mx, my);
            if (id != null) {
                Cfg.resetPos(id);
                Cfg.save();
            }
        }

        String help = "Drag to move  |  Right-click resets  |  Esc to finish";
        int w = this.textRenderer.getWidth(help) + 12;
        Gfx.round(ctx, (this.width - w) / 2, this.height - 22, w, 14, 0xCC120E05);
        Gfx.center(ctx, this.textRenderer, help, this.width / 2, this.height - 19, Gfx.GOLD_LIGHT);
    }
}
