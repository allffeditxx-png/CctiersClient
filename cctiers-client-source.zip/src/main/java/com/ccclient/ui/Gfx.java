package com.ccclient.ui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/** Small drawing helpers (only plain fills + text, so they work on any GUI scale). */
public final class Gfx {
    private Gfx() {}

    // yellowish theme
    public static final int BG = 0xF0120E05;
    public static final int PANEL = 0xF01C1608;
    public static final int CARD = 0xF0261E0B;
    public static final int CARD_HOVER = 0xF0342A10;
    public static final int GOLD = 0xFFF5C518;
    public static final int GOLD_LIGHT = 0xFFFFE27A;
    public static final int GOLD_DARK = 0xFF8A6A0A;
    public static final int TEXT = 0xFFFFF3C4;
    public static final int DIM = 0xFFB09F66;
    public static final int OFF = 0xFF4A4126;

    public static void rect(DrawContext c, int x, int y, int w, int h, int argb) {
        c.fill(x, y, x + w, y + h, argb);
    }

    /** Rectangle with the four corner pixels cut off. */
    public static void round(DrawContext c, int x, int y, int w, int h, int argb) {
        c.fill(x + 1, y, x + w - 1, y + h, argb);
        c.fill(x, y + 1, x + w, y + h - 1, argb);
    }

    public static void outline(DrawContext c, int x, int y, int w, int h, int argb) {
        c.fill(x + 1, y, x + w - 1, y + 1, argb);
        c.fill(x + 1, y + h - 1, x + w - 1, y + h, argb);
        c.fill(x, y + 1, x + 1, y + h - 1, argb);
        c.fill(x + w - 1, y + 1, x + w, y + h - 1, argb);
    }

    public static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    public static void text(DrawContext c, TextRenderer tr, String s, int x, int y, int color) {
        c.drawTextWithShadow(tr, s, x, y, color);
    }

    public static void center(DrawContext c, TextRenderer tr, String s, int cx, int y, int color) {
        c.drawTextWithShadow(tr, s, cx - tr.getWidth(s) / 2, y, color);
    }

    /** Pill button used all over the menu. Returns nothing - hit testing is done by the caller. */
    public static void button(DrawContext c, TextRenderer tr, int x, int y, int w, int h, String label, boolean hover, boolean active) {
        int bg = active ? (hover ? GOLD_LIGHT : GOLD) : (hover ? 0xFF5A4E2C : OFF);
        round(c, x, y, w, h, bg);
        int tc = active ? 0xFF1A1303 : TEXT;
        c.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2 + 1, tc, false);
    }

    /** Wraps text to a pixel width. */
    public static List<String> wrap(TextRenderer tr, String s, int width) {
        List<String> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : s.split(" ")) {
            String trial = line.length() == 0 ? word : line + " " + word;
            if (tr.getWidth(trial) > width && line.length() > 0) {
                out.add(line.toString());
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(trial);
            }
        }
        if (line.length() > 0) out.add(line.toString());
        return out;
    }
}
