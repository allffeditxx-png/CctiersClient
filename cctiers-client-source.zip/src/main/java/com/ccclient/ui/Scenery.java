package com.ccclient.ui;

import net.minecraft.client.gui.DrawContext;

/** Animated sunset mountain scene drawn only with filled rectangles (no textures needed). */
public final class Scenery {
    private Scenery() {}

    private static int a(int alpha, int rgb) {
        return (alpha << 24) | (rgb & 0xFFFFFF);
    }

    private static void disc(DrawContext c, int cx, int cy, int r, int argb) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.sqrt((double) r * r - (double) dy * dy);
            c.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, argb);
        }
    }

    private static double peak(double v) {
        return 1.0 - Math.abs(Math.sin(v));
    }

    /** Height of a ridge line above its base at column x. */
    private static double ridge(int x, double f1, double f2, double p1, double p2, double amp) {
        return amp * (0.62 * peak(x * f1 + p1) + 0.38 * peak(x * f2 + p2));
    }

    public static void draw(DrawContext c, int w, int h, double t) {
        int hz = (int) (h * 0.64);

        // sky
        c.fillGradient(0, 0, w, (int) (h * 0.38), 0xFF140B29, 0xFF3A1F5C);
        c.fillGradient(0, (int) (h * 0.38), w, (int) (h * 0.52), 0xFF3A1F5C, 0xFFB4505F);
        c.fillGradient(0, (int) (h * 0.52), w, hz + 4, 0xFFB4505F, 0xFFFFB347);
        c.fill(0, hz + 4, w, h, 0xFF2A1638);

        // stars
        for (int i = 0; i < 70; i++) {
            int sx = (i * 97 + 31) % Math.max(1, w);
            int sy = (i * 53 + 7) % Math.max(1, (int) (h * 0.36));
            int al = (int) (110 + 100 * Math.sin(t * 1.6 + i * 1.7));
            c.fill(sx, sy, sx + (i % 4 == 0 ? 2 : 1), sy + (i % 4 == 0 ? 2 : 1), a(Math.max(40, Math.min(230, al)), 0xFFF1C8));
        }

        // sun + glow
        int sunX = (int) (w * 0.72), sunY = hz - (int) (h * 0.02), r = Math.max(10, (int) (h * 0.085));
        for (int k = 4; k >= 1; k--) disc(c, sunX, sunY, r + k * (r / 2), a(0x16, 0xFFC060));
        disc(c, sunX, sunY, r, 0xFFFFD36A);
        disc(c, sunX, sunY, r - 3, 0xFFFFE9A0);

        // clouds
        for (int i = 0; i < 5; i++) {
            double speed = 4 + i * 1.5;
            int cw = 50 + i * 14;
            int cx = (int) (((t * speed + i * 140) % (w + 240)) - 120);
            int cy = (int) (h * (0.14 + 0.07 * i)) + (i % 2) * 6;
            c.fill(cx + 6, cy, cx + cw - 6, cy + 3, a(0x66, 0xFFC9A0));
            c.fill(cx, cy + 3, cx + cw, cy + 6, a(0x55, 0xFFB890));
            c.fill(cx + 12, cy - 3, cx + cw - 18, cy, a(0x55, 0xFFD0B0));
        }

        int step = Math.max(1, w / 320);
        // far mountains
        layer(c, w, h, hz + 2, h * 0.20, 0.011, 0.027, 0.4 + t * 0.012, 1.7, 0xFF7A3F72, step);
        // mid mountains
        layer(c, w, h, hz + (int) (h * 0.07), h * 0.17, 0.016, 0.037, 2.1 + t * 0.02, 0.6, 0xFF4F2A5E, step);
        // near mountains
        layer(c, w, h, hz + (int) (h * 0.15), h * 0.14, 0.021, 0.049, 4.3 + t * 0.03, 2.4, 0xFF2E1B43, step);

        // lake shimmer
        int lakeY = hz + (int) (h * 0.19);
        for (int i = 0; i < 9; i++) {
            int lx = (int) (w * 0.5 + (i - 4) * w * 0.045 + 6 * Math.sin(t * 0.8 + i));
            int lw = (int) (w * 0.03 + 4 * Math.sin(t * 1.3 + i * 2));
            c.fill(lx, lakeY + i % 3 * 3, lx + Math.max(4, lw), lakeY + i % 3 * 3 + 1, a(0x55, 0xFFC87A));
        }

        // foreground ground + pines
        int gBase = hz + (int) (h * 0.27);
        double gAmp = h * 0.05;
        for (int x = 0; x < w; x += step) {
            int y = gBase - (int) ridge(x, 0.017, 0.043, 1.1, 3.0, gAmp);
            c.fill(x, y, x + step, h, 0xFF150E22);
        }
        int trees = Math.max(6, w / 34);
        for (int i = 0; i < trees; i++) {
            int tx = (int) ((i + 0.5) * w / trees + ((i * 37) % 17) - 8);
            int ground = gBase - (int) ridge(Math.max(0, Math.min(w - 1, tx)), 0.017, 0.043, 1.1, 3.0, gAmp);
            int th = (int) (h * (0.13 + 0.03 * (i % 3)));
            pine(c, tx, ground + 2, th, i % 2 == 0 ? 0xFF0E0916 : 0xFF120B1D);
        }

        // fireflies
        for (int i = 0; i < 26; i++) {
            double fx = w * ((i * 0.6180339) % 1.0) + 10 * Math.sin(t * 0.7 + i);
            double fy = h * (0.70 + 0.26 * ((i * 0.4142) % 1.0)) + 6 * Math.sin(t * 0.9 + i * 1.3);
            int al = (int) (150 + 100 * Math.sin(t * 2.2 + i * 2.1));
            al = Math.max(40, Math.min(255, al));
            c.fill((int) fx - 1, (int) fy - 1, (int) fx + 3, (int) fy + 3, a(al / 7, 0xFFE27A));
            c.fill((int) fx, (int) fy, (int) fx + 2, (int) fy + 2, a(al, 0xFFE27A));
        }

        // vignette
        c.fillGradient(0, 0, w, (int) (h * 0.16), 0xA0000000, 0x00000000);
        c.fillGradient(0, (int) (h * 0.82), w, h, 0x00000000, 0xB0000000);
    }

    private static void layer(DrawContext c, int w, int h, int base, double amp, double f1, double f2, double p1, double p2, int col, int step) {
        for (int x = 0; x < w; x += step) {
            int y = base - (int) ridge(x, f1, f2, p1, p2, amp);
            c.fill(x, y, x + step, h, col);
        }
    }

    private static void pine(DrawContext c, int cx, int baseY, int th, int col) {
        int top = baseY - th;
        int tw = Math.max(8, th / 2);
        c.fill(cx - 1, baseY - th / 8, cx + 1, baseY, col);
        for (int tier = 0; tier < 3; tier++) {
            int tierTop = top + tier * (th / 4);
            int tierH = th / 2;
            for (int row = 0; row < tierH; row += 2) {
                int half = (int) ((row / (double) tierH) * (tw / 2.0) * (0.6 + 0.2 * tier)) + 1;
                c.fill(cx - half, tierTop + row, cx + half + 1, tierTop + row + 2, col);
            }
        }
    }
}
