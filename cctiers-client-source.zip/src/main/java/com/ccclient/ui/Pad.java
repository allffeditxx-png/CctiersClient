package com.ccclient.ui;

import org.lwjgl.glfw.GLFW;

/** Polls the mouse buttons straight from GLFW so the custom screens don't depend on screen input callbacks. */
public final class Pad {
    public boolean l, r, pl, pr;

    public void sync(long win) {
        l = pl = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        r = pr = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
    }

    public void poll(long win) {
        pl = l;
        pr = r;
        l = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        r = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
    }

    public boolean lPress() {
        return l && !pl;
    }

    public boolean lRelease() {
        return !l && pl;
    }

    public boolean rPress() {
        return r && !pr;
    }

    public static boolean key(long win, int key) {
        return GLFW.glfwGetKey(win, key) == GLFW.GLFW_PRESS;
    }
}
