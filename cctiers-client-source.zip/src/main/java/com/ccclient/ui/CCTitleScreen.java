package com.ccclient.ui;

import com.ccclient.data.GameMode;
import com.ccclient.data.Profile;
import com.ccclient.data.Rank;
import com.ccclient.data.TierApi;
import com.ccclient.data.TierText;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;

/** Replaces the vanilla title screen: scenery, the player's CCTiers tiers on top, and custom buttons. */
public class CCTitleScreen extends Screen {
    private final Pad pad = new Pad();
    private final float[] anim = new float[6];
    private long lastNs = System.nanoTime();

    // letter bitmaps for the logo (5 x 7)
    private static final String[] GLYPH_C = {".XXX.", "X...X", "X....", "X....", "X....", "X...X", ".XXX."};
    private static final String[] GLYPH_L = {"X....", "X....", "X....", "X....", "X....", "X....", "XXXXX"};
    private static final String[] GLYPH_I = {"XXXXX", "..X..", "..X..", "..X..", "..X..", "..X..", "XXXXX"};
    private static final String[] GLYPH_E = {"XXXXX", "X....", "X....", "XXXX.", "X....", "X....", "XXXXX"};
    private static final String[] GLYPH_R = {"XXXX.", "X...X", "X...X", "XXXX.", "X.X..", "X..X.", "X...X"};
    private static final String[] GLYPH_S = {".XXXX", "X....", "X....", ".XXX.", "....X", "....X", "XXXX."};
    private static final String[] GLYPH_N = {"X...X", "XX..X", "XX..X", "X.X.X", "X..XX", "X..XX", "X...X"};
    private static final String[] GLYPH_T = {"XXXXX", "..X..", "..X..", "..X..", "..X..", "..X..", "..X.."};

    public CCTitleScreen() {
        super(Text.literal("CcTiers Client"));
    }

    @Override
    protected void init() {
        pad.sync(this.client.getWindow().getHandle());
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        MinecraftClient mc = this.client;
        TextRenderer tr = this.textRenderer;
        pad.poll(mc.getWindow().getHandle());
        long nowNs = System.nanoTime();
        float dt = Math.min(0.1f, (nowNs - lastNs) / 1_000_000_000f);
        lastNs = nowNs;

        Scenery.draw(ctx, this.width, this.height, System.currentTimeMillis() / 1000.0);

        int y = drawTiers(ctx, tr, mc) + 8;

        // logo
        int px = this.height >= 260 ? 4 : this.height >= 200 ? 3 : 2;
        String[][] letters = {GLYPH_C, GLYPH_C, GLYPH_T, GLYPH_I, GLYPH_E, GLYPH_R, GLYPH_S};
        int letterW = 5 * px, spacing = px;
        int total = 0;
        for (String[] g : letters) total += (g == null ? 3 * px : letterW) + spacing;
        total -= spacing;
        int lx = (this.width - total) / 2;
        for (String[] g : letters) {
            if (g == null) {
                lx += 3 * px + spacing;
                continue;
            }
            for (int r = 0; r < 7; r++) {
                for (int cc = 0; cc < 5; cc++) {
                    if (g[r].charAt(cc) == 'X') {
                        int bx = lx + cc * px, by = y + r * px;
                        ctx.fill(bx + 1, by + 1, bx + px + 1, by + px + 1, 0xAA000000);
                        ctx.fill(bx, by, bx + px, by + px, Gfx.GOLD);
                        ctx.fill(bx, by, bx + px, by + 1, Gfx.GOLD_LIGHT);
                    }
                }
            }
            lx += letterW + spacing;
        }
        y += 7 * px + 4;
        Gfx.center(ctx, tr, "C  L  I  E  N  T", this.width / 2, y, Gfx.GOLD_LIGHT);
        y += 14;

        // buttons
        int avail = this.height - y - 20;
        boolean tight = avail < 118;
        int bh = tight ? 18 : 24, bgap = tight ? 3 : 5;
        int bw = Math.min(190, this.width - 24);
        int bx = (this.width - bw) / 2;

        String[] labels = {"Singleplayer", "Multiplayer", "HUD Settings"};
        Runnable[] actions = {
                () -> mc.setScreen(new SelectWorldScreen(this)),
                () -> mc.setScreen(new MultiplayerScreen(this)),
                () -> mc.setScreen(new MenuScreen(this))
        };
        for (int i = 0; i < 3; i++) {
            bigButton(ctx, tr, i, labels[i], bx, y, bw, bh, mx, my, dt, actions[i]);
            y += bh + bgap;
        }
        int sw = (bw - 4) / 2;
        smallButton(ctx, tr, 3, "Options", bx, y, sw, bh - 3, mx, my, dt, () -> mc.setScreen(new OptionsScreen(this, mc.options)));
        smallButton(ctx, tr, 4, "Quit", bx + sw + 4, y, sw, bh - 3, mx, my, dt, mc::scheduleStop);

        Gfx.text(ctx, tr, "CcTiers Client by AyushXDP", 6, this.height - 12, 0xCCFFF3C4);
        String ver = "Minecraft 1.21.11";
        Gfx.text(ctx, tr, ver, this.width - 6 - tr.getWidth(ver), this.height - 12, 0xCCFFF3C4);
    }

    private void bigButton(DrawContext ctx, TextRenderer tr, int idx, String label, int x, int y, int w, int h, int mx, int my, float dt, Runnable action) {
        boolean hov = Gfx.inside(mx, my, x, y, w, h);
        anim[idx] += ((hov ? 1f : 0f) - anim[idx]) * Math.min(1f, dt * 14f);
        float a = anim[idx];
        int shift = Math.round(a * 4);
        Gfx.round(ctx, x - shift, y, w + shift * 2, h, a > 0.5f ? Gfx.GOLD : 0xDD1C1608);
        if (a <= 0.5f) {
            Gfx.rect(ctx, x - shift, y, 3 + Math.round(a * 8), h, Gfx.GOLD);
            Gfx.outline(ctx, x - shift, y, w + shift * 2, h, Gfx.GOLD_DARK);
        }
        int tc = a > 0.5f ? 0xFF1A1303 : Gfx.TEXT;
        ctx.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2 + 1, tc, false);
        if (hov && pad.lRelease()) action.run();
    }

    private void smallButton(DrawContext ctx, TextRenderer tr, int idx, String label, int x, int y, int w, int h, int mx, int my, float dt, Runnable action) {
        boolean hov = Gfx.inside(mx, my, x, y, w, h);
        anim[idx] += ((hov ? 1f : 0f) - anim[idx]) * Math.min(1f, dt * 14f);
        Gfx.round(ctx, x, y, w, h, anim[idx] > 0.5f ? Gfx.GOLD : 0xDD1C1608);
        Gfx.outline(ctx, x, y, w, h, Gfx.GOLD_DARK);
        ctx.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2 + 1, anim[idx] > 0.5f ? 0xFF1A1303 : Gfx.TEXT, false);
        if (hov && pad.lRelease()) action.run();
    }

    /** Draws the tier strip at the top. Returns the y where it ends. */
    private int drawTiers(DrawContext ctx, TextRenderer tr, MinecraftClient mc) {
        String name = mc.getSession() == null ? "" : mc.getSession().getUsername();
        int pw = Math.min(this.width - 12, 470);
        int px = (this.width - pw) / 2, py = 6;

        TierApi.Entry e = TierApi.get(name);
        GameMode[] modes = GameMode.values();
        boolean ready = e != null && e.state == TierApi.State.READY && e.profile != null;

        int chipW = 40, chipH = 14, cgap = 3;
        int perRow = Math.max(1, (pw - 10 + cgap) / (chipW + cgap));
        int rows = ready ? (modes.length + perRow - 1) / perRow : 0;
        int ph = 18 + rows * (chipH + cgap) + (ready ? 2 : 0);

        Gfx.round(ctx, px, py, pw, ph, 0x99000000);
        Gfx.outline(ctx, px, py, pw, ph, Gfx.GOLD_DARK);
        Gfx.text(ctx, tr, name.isEmpty() ? "Player" : name, px + 6, py + 5, Gfx.GOLD);
        int nameW = tr.getWidth(name.isEmpty() ? "Player" : name);

        String info;
        if (e == null) info = "Tiers need a valid username";
        else if (e.state == TierApi.State.LOADING) info = "Loading tiers...";
        else if (e.state == TierApi.State.ERROR) info = "Can't reach the tier server";
        else if (e.state == TierApi.State.NOT_FOUND) info = "Not on CCTiers yet";
        else {
            Profile p = e.profile;
            info = (p.region == null || p.region.isEmpty() ? "" : "Region " + p.region + "  |  ") + "Overall #" + (p.overall > 0 ? p.overall : "-") + "  |  " + p.points + " pts";
        }
        Gfx.text(ctx, tr, info, px + 12 + nameW, py + 5, Gfx.TEXT);

        if (ready) {
            Profile p = e.profile;
            int total = Math.min(modes.length, perRow);
            int rowW = total * chipW + (total - 1) * cgap;
            int sx = px + (pw - rowW) / 2;
            for (int i = 0; i < modes.length; i++) {
                int cx = sx + (i % perRow) * (chipW + cgap);
                int cy = py + 18 + (i / perRow) * (chipH + cgap);
                Rank r = p.forMode(modes[i]);
                int accent = r == null ? 0xFF444444 : (0xFF000000 | r.color());
                Gfx.round(ctx, cx, cy, chipW, chipH, 0xCC141008);
                Gfx.rect(ctx, cx, cy + chipH - 2, chipW, 2, accent);
                ctx.drawTextWithShadow(tr, TierText.icon(modes[i]), cx + 3, cy + 2, 0xFFFFFFFF);
                String label = r == null ? "-" : r.label();
                ctx.drawTextWithShadow(tr, label, cx + 16, cy + 3, accent);
            }
        }
        return py + ph;
    }
}
