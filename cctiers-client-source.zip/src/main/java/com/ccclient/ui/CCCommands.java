package com.ccclient.ui;

import com.ccclient.CCClient;
import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.command.CommandRegistryAccess;

/** /ccclient opens the menu (handy on launchers without a Right Shift key). */
public final class CCCommands {
    private CCCommands() {}

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher, CommandRegistryAccess access) {
        dispatcher.register(ClientCommandManager.literal("ccclient").executes(ctx -> {
            CCClient.openMenuNextTick = true;
            return 1;
        }));
    }
}
