package com.ccclient.ui;

import com.ccclient.core.Cfg;
import com.ccclient.core.Mod;
import com.ccclient.core.Opt;
import com.ccclient.core.Palette;
import com.ccclient.core.Stats;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Right Shift menu: every feature is a card with an enable button. Right-click (or Edit) opens the card's settings. */
public class MenuScreen extends Screen {
    private final Screen parent;
    private final Pad pad = new Pad();

    private Mod.Cat tab = Mod.Cat.INFO;
    private float scroll = 0, editScroll = 0;
    private Mod editing = null;
    private Hit slider = null;
    private int pressX, pressY;
    private boolean pressing, dragged;
    private float scrollAtPress;
    private boolean shiftPrev;

    private int maxScroll = 0, maxEditScroll = 0;

    private static final class Hit {
        final int x, y, w, h;
        Runnable left, right;
        int[] clip;
        Opt opt;
        Mod mod;
        int sx0, sx1;

        Hit(int x, int y, int w, int h, Runnable left) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.left = left;
        }

        boolean contains(int mx, int my) {
            if (!Gfx.inside(mx, my, x, y, w, h)) return false;
            return clip == null || Gfx.inside(mx, my, clip[0], clip[1], clip[2], clip[3]);
        }
    }

    private final List<Hit> hits = new ArrayList<>();

    public MenuScreen(Screen parent) {
        super(Text.literal("CcTiers Client"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        long win = this.client.getWindow().getHandle();
        pad.sync(win);
        shiftPrev = Pad.key(win, GLFW.GLFW_KEY_RIGHT_SHIFT);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        if (editing != null) {
            editing = null;
            Cfg.save();
            return;
        }
        Cfg.save();
        this.client.setScreen(parent);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (editing != null) editScroll -= (float) verticalAmount * 20f;
        else scroll -= (float) verticalAmount * 24f;
        return true;
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        long win = this.client.getWindow().getHandle();
        pad.poll(win);
        boolean sh = Pad.key(win, GLFW.GLFW_KEY_RIGHT_SHIFT);
        if (sh && !shiftPrev) {
            Cfg.save();
            this.client.setScreen(parent);
            return;
        }
        shiftPrev = sh;

        TextRenderer tr = this.textRenderer;
        hits.clear();

        if (this.client.world == null) Scenery.draw(ctx, this.width, this.height, System.currentTimeMillis() / 1000.0);
        ctx.fill(0, 0, this.width, this.height, this.client.world == null ? 0x77000000 : 0xA0000000);

        int pw = Math.min(this.width - 8, 440);
        int ph = Math.min(this.height - 8, 300);
        int px = (this.width - pw) / 2;
        int py = (this.height - ph) / 2;
        Gfx.round(ctx, px, py, pw, ph, Gfx.PANEL);
        Gfx.outline(ctx, px, py, pw, ph, Gfx.GOLD_DARK);
        Gfx.rect(ctx, px + 1, py + 1, pw - 2, 2, Gfx.GOLD);

        Gfx.text(ctx, tr, "CcTiers Client", px + 8, py + 8, Gfx.GOLD);
        String hint = "Right Shift to close";
        Gfx.text(ctx, tr, hint, px + pw - 8 - tr.getWidth(hint), py + 8, Gfx.DIM);

        // tabs
        int tx = px + 8, ty = py + 22, tabH = 14;
        for (Mod.Cat c : Mod.Cat.values()) {
            int tw = tr.getWidth(c.label) + 12;
            if (tx + tw > px + pw - 8) {
                tx = px + 8;
                ty += tabH + 2;
            }
            boolean hov = editing == null && Gfx.inside(mx, my, tx, ty, tw, tabH);
            Gfx.button(ctx, tr, tx, ty, tw, tabH, c.label, hov, c == tab);
            if (editing == null) {
                final Mod.Cat cc = c;
                hits.add(new Hit(tx, ty, tw, tabH, () -> {
                    tab = cc;
                    scroll = 0;
                }));
            }
            tx += tw + 3;
        }

        // cards
        int cx0 = px + 8, cy0 = ty + tabH + 6, cw = pw - 16;
        int ch = (py + ph - 26) - cy0;
        int gap = 4, cardH = 52;
        int cols = Math.max(1, (cw + gap) / (118 + gap));
        int cardW = (cw - (cols - 1) * gap) / cols;
        List<Mod> list = new ArrayList<>();
        for (Mod m : Mod.ALL) if (m.cat == tab) list.add(m);
        int rows = (list.size() + cols - 1) / cols;
        int total = rows * (cardH + gap);
        maxScroll = Math.max(0, total - ch);
        scroll = Math.max(0, Math.min(maxScroll, scroll));
        int[] clip = {cx0, cy0, cw, ch};

        ctx.enableScissor(cx0, cy0, cx0 + cw, cy0 + ch);
        for (int i = 0; i < list.size(); i++) {
            Mod m = list.get(i);
            int x = cx0 + (i % cols) * (cardW + gap);
            int y = cy0 + (i / cols) * (cardH + gap) - (int) scroll;
            if (y + cardH < cy0 || y > cy0 + ch) continue;
            drawCard(ctx, tr, m, x, y, cardW, cardH, mx, my, clip);
        }
        ctx.disableScissor();

        if (maxScroll > 0) {
            int trackH = ch;
            int barH = Math.max(12, trackH * ch / (total));
            int barY = cy0 + (int) ((trackH - barH) * (scroll / maxScroll));
            Gfx.rect(ctx, px + pw - 5, barY, 2, barH, Gfx.GOLD_DARK);
        }

        // bottom bar
        int by = py + ph - 20;
        int bw = (pw - 16 - 4) / 2;
        bottomButton(ctx, tr, "Edit HUD Layout", px + 8, by, bw, mx, my, () -> {
            if (this.client.world != null) this.client.setScreen(new HudEditorScreen(this));
        });
        bottomButton(ctx, tr, "Reset stats", px + 8 + bw + 4, by, bw, mx, my, Stats::resetSession);

        if (editing != null) drawEditor(ctx, tr, mx, my);

        handleInput(mx, my);
    }

    private void bottomButton(DrawContext ctx, TextRenderer tr, String label, int x, int y, int w, int mx, int my, Runnable r) {
        boolean hov = editing == null && Gfx.inside(mx, my, x, y, w, 14);
        Gfx.button(ctx, tr, x, y, w, 14, label, hov, false);
        if (editing == null) hits.add(new Hit(x, y, w, 14, r));
    }

    private void drawCard(DrawContext ctx, TextRenderer tr, Mod m, int x, int y, int w, int h, int mx, int my, int[] clip) {
        boolean on = Cfg.on(m.id);
        boolean hov = editing == null && Gfx.inside(mx, my, x, y, w, h) && Gfx.inside(mx, my, clip[0], clip[1], clip[2], clip[3]);
        Gfx.round(ctx, x, y, w, h, hov ? Gfx.CARD_HOVER : Gfx.CARD);
        Gfx.outline(ctx, x, y, w, h, on ? Gfx.GOLD : Gfx.OFF);
        Gfx.text(ctx, tr, m.name, x + 5, y + 5, on ? Gfx.GOLD_LIGHT : Gfx.TEXT);
        List<String> lines = Gfx.wrap(tr, m.desc, w - 10);
        for (int i = 0; i < Math.min(2, lines.size()); i++) {
            ctx.drawText(tr, lines.get(i), x + 5, y + 16 + i * 9, Gfx.DIM, false);
        }
        boolean hasEdit = !m.opts.isEmpty();
        int bx = x + 5, by = y + h - 16, bh = 12;
        int editW = hasEdit ? 32 : 0;
        int toggleW = w - 10 - (hasEdit ? editW + 3 : 0);
        Gfx.button(ctx, tr, bx, by, toggleW, bh, on ? "ENABLED" : "DISABLED", hov && Gfx.inside(mx, my, bx, by, toggleW, bh), on);
        if (hasEdit) {
            Gfx.button(ctx, tr, bx + toggleW + 3, by, editW, bh, "Edit", hov && Gfx.inside(mx, my, bx + toggleW + 3, by, editW, bh), false);
        }
        if (editing == null) {
            Hit card = new Hit(x, y, w, h, () -> Cfg.setOn(m.id, !Cfg.on(m.id)));
            card.right = () -> editing = m;
            card.clip = clip;
            hits.add(card);
            if (hasEdit) {
                Hit eb = new Hit(bx + toggleW + 3, by, editW, bh, () -> {
                    editing = m;
                    editScroll = 0;
                });
                eb.right = () -> editing = m;
                eb.clip = clip;
                hits.add(eb);
            }
        }
    }

    // ------------------------------------------------------------------ editor

    private void drawEditor(DrawContext ctx, TextRenderer tr, int mx, int my) {
        Mod m = editing;
        ctx.fill(0, 0, this.width, this.height, 0x88000000);
        int rowH = 20;
        int rows = 1 + m.opts.size();
        int ew = Math.min(this.width - 12, 290);
        int eh = Math.min(this.height - 12, 22 + rows * rowH + 30);
        int ex = (this.width - ew) / 2, ey = (this.height - eh) / 2;
        Gfx.round(ctx, ex, ey, ew, eh, Gfx.BG);
        Gfx.outline(ctx, ex, ey, ew, eh, Gfx.GOLD);
        Gfx.text(ctx, tr, m.name, ex + 8, ey + 7, Gfx.GOLD);

        hits.clear();
        Hit panel = new Hit(ex, ey, ew, eh, () -> {});
        hits.add(panel);

        int cy0 = ey + 20, cy1 = ey + eh - 26;
        int[] clip = {ex, cy0, ew, cy1 - cy0};
        maxEditScroll = Math.max(0, rows * rowH - (cy1 - cy0));
        editScroll = Math.max(0, Math.min(maxEditScroll, editScroll));

        ctx.enableScissor(ex, cy0, ex + ew, cy1);
        int y = cy0 - (int) editScroll;
        // enabled row
        Gfx.text(ctx, tr, "Enabled", ex + 8, y + 6, Gfx.TEXT);
        toggle(ctx, tr, ex + ew - 8 - 38, y + 4, 38, Cfg.on(m.id), mx, my, () -> Cfg.setOn(m.id, !Cfg.on(m.id)), clip);
        y += rowH;
        for (Opt o : m.opts) {
            Gfx.text(ctx, tr, o.label, ex + 8, y + 6, Gfx.TEXT);
            int cur = Cfg.val(m.id, o.key);
            switch (o.type) {
                case BOOL:
                    toggle(ctx, tr, ex + ew - 8 - 38, y + 4, 38, cur != 0, mx, my, () -> {
                        Cfg.setVal(m.id, o.key, cur != 0 ? 0 : 1);
                        Cfg.save();
                    }, clip);
                    break;
                case INT: {
                    int x1 = ex + ew - 8 - 26;
                    int x0 = ex + Math.max(96, ew * 45 / 100);
                    Gfx.rect(ctx, x0, y + 9, x1 - x0, 3, Gfx.OFF);
                    float f = (cur - o.min) / (float) Math.max(1, o.max - o.min);
                    int kx = x0 + Math.round(f * (x1 - x0));
                    Gfx.rect(ctx, x0, y + 9, kx - x0, 3, Gfx.GOLD_DARK);
                    Gfx.rect(ctx, kx - 2, y + 5, 5, 11, Gfx.GOLD);
                    String v = String.valueOf(cur);
                    ctx.drawText(tr, v, ex + ew - 8 - tr.getWidth(v), y + 6, Gfx.TEXT, false);
                    Hit sl = new Hit(x0 - 3, y + 2, x1 - x0 + 6, 16, null);
                    sl.opt = o;
                    sl.mod = m;
                    sl.sx0 = x0;
                    sl.sx1 = x1;
                    sl.clip = clip;
                    hits.add(sl);
                    break;
                }
                case COLOR: {
                    int sx = ex + ew - 8 - Palette.COUNT * 11 + 2;
                    for (int i = 0; i < Palette.COUNT; i++) {
                        int px = sx + i * 11;
                        int col = Palette.argb(i, i * 6);
                        Gfx.rect(ctx, px, y + 5, 9, 9, col);
                        if (i == cur) Gfx.outline(ctx, px - 1, y + 4, 11, 11, 0xFFFFFFFF);
                        final int idx = i;
                        Hit hh = new Hit(px, y + 4, 10, 11, () -> {
                            Cfg.setVal(m.id, o.key, idx);
                            Cfg.save();
                        });
                        hh.clip = clip;
                        hits.add(hh);
                    }
                    break;
                }
                default: { // CHOICE
                    int bw = 66;
                    int bx = ex + ew - 8 - bw;
                    String label = o.choices[Math.max(0, Math.min(o.choices.length - 1, cur))];
                    Gfx.button(ctx, tr, bx, y + 3, bw, 14, label, Gfx.inside(mx, my, bx, y + 3, bw, 14), false);
                    Hit hh = new Hit(bx, y + 3, bw, 14, () -> {
                        Cfg.setVal(m.id, o.key, (cur + 1) % o.choices.length);
                        Cfg.save();
                    });
                    hh.right = () -> {
                        Cfg.setVal(m.id, o.key, (cur + o.choices.length - 1) % o.choices.length);
                        Cfg.save();
                    };
                    hh.clip = clip;
                    hits.add(hh);
                    break;
                }
            }
            y += rowH;
        }
        ctx.disableScissor();

        int by = ey + eh - 22;
        int bw = (ew - 24) / 2;
        Gfx.button(ctx, tr, ex + 8, by, bw, 14, "Reset", Gfx.inside(mx, my, ex + 8, by, bw, 14), false);
        hits.add(new Hit(ex + 8, by, bw, 14, () -> Cfg.resetModule(m)));
        Gfx.button(ctx, tr, ex + 16 + bw, by, bw, 14, "Done", Gfx.inside(mx, my, ex + 16 + bw, by, bw, 14), true);
        hits.add(new Hit(ex + 16 + bw, by, bw, 14, () -> {
            editing = null;
            Cfg.save();
        }));
    }

    private void toggle(DrawContext ctx, TextRenderer tr, int x, int y, int w, boolean on, int mx, int my, Runnable r, int[] clip) {
        Gfx.button(ctx, tr, x, y, w, 12, on ? "ON" : "OFF", Gfx.inside(mx, my, x, y, w, 12), on);
        Hit h = new Hit(x, y, w, 12, r);
        h.clip = clip;
        hits.add(h);
    }

    // ------------------------------------------------------------------ input

    private Hit hitAt(int mx, int my, boolean needLeft, boolean needRight) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.contains(mx, my)) continue;
            if (needLeft && h.left == null && h.opt == null) continue;
            if (needRight && h.right == null) continue;
            return h;
        }
        return null;
    }

    private void applySlider(Hit h, int mx) {
        float f = (mx - h.sx0) / (float) Math.max(1, h.sx1 - h.sx0);
        f = Math.max(0f, Math.min(1f, f));
        Opt o = h.opt;
        int v = o.min + Math.round(f * (o.max - o.min) / (float) o.step) * o.step;
        Cfg.setVal(h.mod.id, o.key, Math.max(o.min, Math.min(o.max, v)));
    }

    private void handleInput(int mx, int my) {
        if (pad.lPress()) {
            pressX = mx;
            pressY = my;
            pressing = true;
            dragged = false;
            scrollAtPress = editing != null ? editScroll : scroll;
            Hit h = hitAt(mx, my, false, false);
            if (editing != null && h != null && h.opt != null) {
                slider = h;
                applySlider(h, mx);
            }
        }
        if (pad.l && pressing && slider == null) {
            if (!dragged && Math.abs(my - pressY) > 5) dragged = true;
            if (dragged) {
                float s = scrollAtPress - (my - pressY);
                if (editing != null) editScroll = Math.max(0, Math.min(maxEditScroll, s));
                else scroll = Math.max(0, Math.min(maxScroll, s));
            }
        }
        if (slider != null && pad.l) applySlider(slider, mx);
        if (pad.lRelease()) {
            if (slider != null) {
                slider = null;
                Cfg.save();
            } else if (pressing && !dragged) {
                Hit h = hitAt(mx, my, true, false);
                if (h != null && h.left != null) {
                    h.left.run();
                    Cfg.save();
                } else if (editing != null) {
                    // click outside the editor closes it
                    boolean inPanel = false;
                    for (Hit x : hits) if (x.left != null && x.contains(mx, my)) inPanel = true;
                    if (!inPanel && !hits.isEmpty() && !hits.get(0).contains(mx, my)) editing = null;
                }
            }
            pressing = false;
        }
        if (pad.rPress()) {
            Hit h = hitAt(mx, my, false, true);
            if (h != null) {
                h.right.run();
                editScroll = 0;
                Cfg.save();
            }
        }
    }
}
