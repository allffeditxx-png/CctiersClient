package com.ccclient.mixin;

import com.ccclient.blur.BlurPackProvider;
import net.minecraft.resource.ResourcePackManager;
import net.minecraft.resource.ResourcePackProvider;
import net.minecraft.resource.VanillaResourcePackProvider;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.LinkedHashSet;
import java.util.Set;

/** Adds the locked blur pack to the game's resource pack manager. */
@Mixin(ResourcePackManager.class)
public abstract class ResourcePackManagerMixin {

    @Shadow
    @Final
    @Mutable
    private Set<ResourcePackProvider> providers;

    @Inject(method = "<init>", at = @At("RETURN"))
    private void ccclient$addBlurPack(ResourcePackProvider[] given, CallbackInfo ci) {
        for (ResourcePackProvider p : given) {
            if (p instanceof VanillaResourcePackProvider) {
                Set<ResourcePackProvider> set = new LinkedHashSet<>(this.providers);
                set.add(new BlurPackProvider());
                this.providers = set;
                break;
            }
        }
    }
}
