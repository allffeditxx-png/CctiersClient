package com.ccclient.mixin;

import com.ccclient.data.TierTag;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** The nametag above a player is rendered from PlayerEntity#getDisplayName. */
@Mixin(PlayerEntity.class)
public abstract class PlayerDisplayNameMixin {

    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true)
    private void ccclient$addTag(CallbackInfoReturnable<Text> cir) {
        Text tagged = TierTag.nametag((PlayerEntity) (Object) this, cir.getReturnValue());
        if (tagged != null) cir.setReturnValue(tagged);
    }
}
