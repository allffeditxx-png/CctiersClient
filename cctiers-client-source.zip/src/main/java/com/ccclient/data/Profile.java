package com.ccclient.data;


import java.util.Comparator;
import java.util.List;

public final class Profile {
    public final String name;
    public final String region;
    public final int points;
    public final int overall;
    public final List<Rank> ranks;

    public Profile(String name, String region, int points, int overall, List<Rank> ranks) {
        this.name = name;
        this.region = region;
        this.points = points;
        this.overall = overall;
        this.ranks = ranks;
    }

    public Profile withOverall(int newOverall) {
        return new Profile(name, region, points, newOverall, ranks);
    }

    public Rank forMode(GameMode mode) {
        for (Rank r : ranks) {
            if (r.mode() == mode) return r;
        }
        return null;
    }

    /** Best rank (HT1 > LT1 > HT2 ...). */
    public Rank best() {
        return ranks.stream().min(Comparator.comparingInt(Rank::score)).orElse(null);
    }

}
