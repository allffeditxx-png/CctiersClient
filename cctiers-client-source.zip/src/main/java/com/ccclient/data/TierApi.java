package com.ccclient.data;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

/** Same API as CCTiers: GET /players once, kept in memory, refreshed every 5 minutes. get() never blocks. */
public final class TierApi {
    private TierApi() {}

    public static final String URL = "https://api.hypen9.qzz.io/players";

    public enum State { LOADING, READY, NOT_FOUND, ERROR }

    public static final class Entry {
        public final State state;
        public final Profile profile;
        public final String error;

        Entry(State state, Profile profile, String error) {
            this.state = state;
            this.profile = profile;
            this.error = error;
        }
    }

    private static final Entry LOADING = new Entry(State.LOADING, null, "");
    private static final Entry NOT_FOUND = new Entry(State.NOT_FOUND, null, "");
    private static final Pattern VALID_NAME = Pattern.compile("^[A-Za-z0-9_]{3,16}$");
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
    private static final ExecutorService POOL = Executors.newFixedThreadPool(1, r -> {
        Thread t = new Thread(r, "ccclient-net");
        t.setDaemon(true);
        return t;
    });

    private static volatile Map<String, Profile> players = null;
    private static volatile long loadedAt = 0L;
    private static volatile long lastAttempt = 0L;
    private static volatile boolean loading = false;
    private static volatile String loadError = "";

    public static Entry get(String name) {
        if (name == null || !VALID_NAME.matcher(name).matches()) return null;
        ensureLoaded();
        Map<String, Profile> map = players;
        if (map == null) {
            if (!loading && !loadError.isEmpty()) return new Entry(State.ERROR, null, loadError);
            return LOADING;
        }
        Profile p = map.get(name.toLowerCase(Locale.ROOT));
        return p == null ? NOT_FOUND : new Entry(State.READY, p, "");
    }

    public static void ensureLoaded() {
        if (loading) return;
        long now = System.currentTimeMillis();
        boolean need = players == null ? now - lastAttempt > 30_000L : now - loadedAt > 5 * 60_000L;
        if (need) load();
    }

    public static void refresh() {
        if (!loading) {
            loadedAt = 0L;
            lastAttempt = 0L;
            load();
        }
    }

    private static synchronized void load() {
        if (loading) return;
        loading = true;
        lastAttempt = System.currentTimeMillis();
        POOL.submit(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder(URI.create(URL))
                        .timeout(Duration.ofSeconds(20))
                        .header("Accept", "application/json")
                        .header("User-Agent", "CcTiersClient/1.0 (by AyushXDP)")
                        .GET().build();
                HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
                if (res.statusCode() < 200 || res.statusCode() >= 300) {
                    loadError = "HTTP " + res.statusCode();
                } else {
                    players = ProfileParser.parseAll(res.body());
                    loadedAt = System.currentTimeMillis();
                    loadError = "";
                }
            } catch (Exception ex) {
                loadError = ex.getClass().getSimpleName();
            } finally {
                loading = false;
            }
        });
    }
}
