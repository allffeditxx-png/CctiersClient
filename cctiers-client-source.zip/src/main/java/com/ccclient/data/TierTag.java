package com.ccclient.data;

import com.ccclient.core.Cfg;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.text.TextCodecs;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;

import java.util.Optional;

/** The "CcTiers Tag" card: CcTiers logo + tier next to the nametag (left or right). */
public final class TierTag {
    private TierTag() {}

    private static final String FONT = "ccclient:gm";
    public static final char LOGO = '\uE100';

    private static JsonObject part(String text, String color, boolean icon) {
        JsonObject o = new JsonObject();
        o.addProperty("text", text);
        o.addProperty("color", color);
        o.addProperty("bold", false);
        if (icon) o.addProperty("font", FONT);
        return o;
    }

    private static Text parse(JsonArray extra, Text fallback) {
        JsonObject root = new JsonObject();
        root.addProperty("text", "");
        root.add("extra", extra);
        Optional<Text> parsed = TextCodecs.CODEC.parse(JsonOps.INSTANCE, root).result();
        return parsed.orElse(fallback);
    }

    private static Rank pick(Profile p) {
        int m = Cfg.val("cctiers_tag", "mode");
        Rank r = null;
        GameMode[] modes = GameMode.values();
        if (m >= 1 && m <= modes.length) r = p.forMode(modes[m - 1]);
        return r != null ? r : p.best();
    }

    /** "[logo] HT3 | " (left) or " | HT3 [logo]" (right). Null if there is nothing to show. */
    private static Text build(Rank r, boolean left) {
        boolean logo = Cfg.flag("cctiers_tag", "logo");
        boolean tier = Cfg.flag("cctiers_tag", "tier") && r != null;
        if (!logo && !tier) return null;
        String hex = tier ? String.format("#%06X", r.color()) : "#FFFFFF";
        JsonArray extra = new JsonArray();
        MutableText fallback = Text.empty();
        if (left) {
            if (logo) {
                extra.add(part(String.valueOf(LOGO), "white", true));
                if (tier) extra.add(part(" ", "white", false));
            }
            if (tier) {
                extra.add(part(r.label(), hex, false));
                fallback.append(Text.literal(r.label()).styled(s -> s.withColor(TextColor.fromRgb(r.color()))));
            }
            extra.add(part(" | ", "dark_gray", false));
            fallback.append(Text.literal(" | ").formatted(Formatting.DARK_GRAY));
        } else {
            extra.add(part(" | ", "dark_gray", false));
            fallback.append(Text.literal(" | ").formatted(Formatting.DARK_GRAY));
            if (tier) {
                extra.add(part(r.label(), hex, false));
                fallback.append(Text.literal(r.label()).styled(s -> s.withColor(TextColor.fromRgb(r.color()))));
                if (logo) extra.add(part(" ", "white", false));
            }
            if (logo) extra.add(part(String.valueOf(LOGO), "white", true));
        }
        return parse(extra, fallback);
    }

    private static Text decorate(String name, Text original) {
        TierApi.Entry e = TierApi.get(name);
        if (e == null || e.state != TierApi.State.READY || e.profile == null) return null;
        boolean left = Cfg.val("cctiers_tag", "pos") == 0;
        Text tag = build(pick(e.profile), left);
        if (tag == null) return null;
        return left ? Text.empty().append(tag).append(original) : Text.empty().append(original).append(tag);
    }

    // ---------------------------------------------------------------- called from the mixins

    public static Text nametag(PlayerEntity player, Text original) {
        if (!Cfg.on("cctiers_tag") || original == null) return null;
        if (!(player instanceof AbstractClientPlayerEntity)) return null;
        if (player == MinecraftClient.getInstance().player && !Cfg.flag("cctiers_tag", "own")) return null;
        return decorate(player.getName().getString(), original);
    }

    public static Text tab(PlayerListEntry entry, Text original) {
        if (!Cfg.on("cctiers_tag") || !Cfg.flag("cctiers_tag", "tab")) return null;
        String name = entry.getProfile().name();
        return decorate(name, original != null ? original : Text.literal(name));
    }
}
