package com.ccclient;

import com.ccclient.blur.MotionBlur;
import com.ccclient.core.Cfg;
import com.ccclient.core.Mods;
import com.ccclient.core.Stats;
import com.ccclient.data.TierApi;
import com.ccclient.hud.Hud;
import com.ccclient.ui.CCCommands;
import com.ccclient.ui.CCTitleScreen;
import com.ccclient.ui.MenuScreen;
import com.ccclient.ui.Pad;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class CCClient implements ClientModInitializer {
    public static final String ID = "ccclient";

    /** Set by /ccclient so the menu opens on the next tick. */
    public static volatile boolean openMenuNextTick = false;

    private boolean shiftPrev = false;
    private int syncTick = 0;

    @Override
    public void onInitializeClient() {
        Mods.init();
        Cfg.ensureLoaded();

        // HUD cards, drawn after the vanilla HUD
        HudElementRegistry.addLast(Identifier.of(ID, "hud"), (ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            Stats.pollClicks(mc);
            Hud.render(ctx);
        });

        // swings at entities (reach, hits, crits, damage)
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (world.isClient() && player == mc.player) Stats.onAttack(mc, entity, hitResult);
            return ActionResult.PASS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> Cfg.save());
        ClientCommandRegistrationCallback.EVENT.register(CCCommands::register);

        TierApi.ensureLoaded();
    }

    private void tick(MinecraftClient mc) {
        if (mc.getWindow() == null) return;

        // scenic title screen instead of the vanilla one
        if (mc.currentScreen instanceof TitleScreen && mc.world == null) {
            mc.setScreen(new CCTitleScreen());
            return;
        }

        // Right Shift opens the card menu (only when no other screen is open)
        boolean shift = Pad.key(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT);
        if ((shift && !shiftPrev && mc.currentScreen == null && mc.player != null) || openMenuNextTick) {
            openMenuNextTick = false;
            mc.setScreen(new MenuScreen(null));
        }
        shiftPrev = shift;

        Stats.tick(mc);
        MotionBlur.tick(mc);
        if (++syncTick >= 20) {
            syncTick = 0;
            if (!(mc.currentScreen instanceof MenuScreen)) MotionBlur.sync(mc);
        }
    }
}
