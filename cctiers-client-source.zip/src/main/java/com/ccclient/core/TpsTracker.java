package com.ccclient.core;

/** Estimates server TPS from how often the server sends its time update (once every 20 server ticks). */
public final class TpsTracker {
    private TpsTracker() {}

    private static final double[] samples = new double[5];
    private static int count = 0;
    private static long lastNs = 0;
    private static long lastValidMs = 0;

    /** Called by the mixin each time a time update packet arrives. */
    public static synchronized void onUpdate() {
        long now = System.nanoTime();
        if (lastNs != 0) {
            double sec = (now - lastNs) / 1_000_000_000.0;
            if (sec > 0.05 && sec < 30) {
                double tps = Math.min(20.0, 20.0 / sec);
                samples[count % samples.length] = tps;
                count++;
                lastValidMs = System.currentTimeMillis();
            }
        }
        lastNs = now;
    }

    public static synchronized void reset() {
        count = 0;
        lastNs = 0;
        lastValidMs = 0;
    }

    /** null when there is no data yet. */
    public static synchronized Double tps() {
        if (count < 2 || System.currentTimeMillis() - lastValidMs > 15_000) return null;
        int n = Math.min(count, samples.length);
        double sum = 0;
        for (int i = 0; i < n; i++) sum += samples[i];
        return sum / n;
    }
}
