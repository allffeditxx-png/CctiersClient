package com.ccclient.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** CPS, combo, reach and speed. Only observes your own game - nothing is sent or changed. */
public final class Stats {
    private Stats() {}

    private static final ArrayDeque<Long> leftClicks = new ArrayDeque<>();
    private static final ArrayDeque<Long> rightClicks = new ArrayDeque<>();
    private static boolean prevLeft, prevRight;

    public static int combo, hits;
    public static long comboStartMs, lastHitMs;
    public static double reach;
    public static boolean hasReach;

    /** Blocks per second, horizontal and with the vertical part. */
    public static double speedH, speed3;
    private static double lastX, lastY, lastZ;
    private static boolean hasLast;

    private static final class Pending {
        final LivingEntity target;
        final float before;
        final int hurtBefore;
        int ticks = 0;

        Pending(LivingEntity t, float before, int hurtBefore) {
            this.target = t;
            this.before = before;
            this.hurtBefore = hurtBefore;
        }
    }

    private static final List<Pending> pending = new ArrayList<>();
    private static int prevHurt = 0;

    // ---------------------------------------------------------------- clicks (every frame)

    public static void pollClicks(MinecraftClient mc) {
        long win = mc.getWindow().getHandle();
        boolean l = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        long now = System.currentTimeMillis();
        if (mc.currentScreen == null && mc.player != null) {
            if (l && !prevLeft) leftClicks.addLast(now);
            if (r && !prevRight) rightClicks.addLast(now);
        }
        prevLeft = l;
        prevRight = r;
        while (!leftClicks.isEmpty() && now - leftClicks.peekFirst() > 1000) leftClicks.pollFirst();
        while (!rightClicks.isEmpty() && now - rightClicks.peekFirst() > 1000) rightClicks.pollFirst();
    }

    public static int leftCps() {
        return leftClicks.size();
    }

    public static int rightCps() {
        return rightClicks.size();
    }

    // ---------------------------------------------------------------- attacks

    /** Called when you swing at an entity. */
    public static void onAttack(MinecraftClient mc, Entity entity, EntityHitResult hit) {
        ClientPlayerEntity p = mc.player;
        if (p == null || !(entity instanceof LivingEntity target)) return;

        // reach = distance from your eyes to the point you hit
        Vec3d eye = p.getEyePos();
        double d = -1;
        if (hit != null) {
            d = eye.distanceTo(hit.getPos());
        } else {
            Box b = target.getBoundingBox();
            Vec3d end = eye.add(p.getRotationVec(1.0f).multiply(8.0));
            Optional<Vec3d> o = b.raycast(eye, end);
            if (o.isPresent()) d = eye.distanceTo(o.get());
        }
        if (d >= 0) {
            reach = d;
            hasReach = true;
        }

        pending.add(new Pending(target, target.getHealth() + target.getAbsorptionAmount(), target.hurtTime));
    }

    // ---------------------------------------------------------------- tick (20 Hz)

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) {
            pending.clear();
            hasLast = false;
            return;
        }
        long now = System.currentTimeMillis();

        // did the swing really land?
        for (int i = pending.size() - 1; i >= 0; i--) {
            Pending pd = pending.get(i);
            pd.ticks++;
            if (pd.ticks < 2) continue;
            pending.remove(i);
            LivingEntity t = pd.target;
            float after = t.getHealth() + t.getAbsorptionAmount();
            boolean landed = t.isDead() || after < pd.before - 0.01f || (pd.hurtBefore == 0 && t.hurtTime > 0);
            if (landed) {
                hits++;
                if (combo == 0) comboStartMs = now;
                combo++;
                lastHitMs = now;
            }
        }

        // you got hit -> combo ends
        if (p.hurtTime > prevHurt && p.hurtTime > 0) combo = 0;
        prevHurt = p.hurtTime;

        if (combo > 0 && now - lastHitMs > Cfg.val("combo", "timeout") * 1000L) combo = 0;

        // speed
        if (hasLast) {
            double dx = p.getX() - lastX, dy = p.getY() - lastY, dz = p.getZ() - lastZ;
            double h = Math.sqrt(dx * dx + dz * dz) * 20.0;
            double v = Math.sqrt(dx * dx + dy * dy + dz * dz) * 20.0;
            if (h > 200) h = speedH; // teleport
            if (v > 200) v = speed3;
            speedH = speedH * 0.6 + h * 0.4;
            speed3 = speed3 * 0.6 + v * 0.4;
        }
        lastX = p.getX();
        lastY = p.getY();
        lastZ = p.getZ();
        hasLast = true;
    }

    public static void resetSession() {
        combo = 0;
        hits = 0;
        hasReach = false;
    }
}
