package com.ccclient.core;

import com.ccclient.core.Mod.Cat;
import com.ccclient.data.GameMode;

/** Every card in the menu. Call Mods.init() once. */
public final class Mods {
    private Mods() {}

    private static boolean done = false;

    public static void init() {
        if (done) return;
        done = true;

        // ---------------------------------------------------------------- info
        new Mod("fps", "FPS", "Your frame rate.", Cat.INFO, true, true, 0.01f, 0.02f).common();
        new Mod("coords", "Coordinates", "Your X, Y and Z position.", Cat.INFO, true, true, 0.01f, 0.09f)
                .opt(Opt.integer("decimals", "Decimals", 0, 2, 1, 0)).common();
        new Mod("biome", "Biome", "The biome you are standing in.", Cat.INFO, false, true, 0.01f, 0.16f).common();
        new Mod("direction", "Direction", "Which way you are facing.", Cat.INFO, false, true, 0.01f, 0.23f)
                .opt(Opt.bool("degrees", "Show degrees", false)).common();
        new Mod("clock", "Clock", "Real time clock.", Cat.INFO, false, true, 0.80f, 0.30f)
                .opt(Opt.choice("fmt", "Format", 0, "24h", "12h"))
                .opt(Opt.bool("seconds", "Show seconds", false)).common();
        new Mod("memory", "Memory Usage", "Game memory in use.", Cat.INFO, false, true, 0.80f, 0.16f)
                .opt(Opt.choice("mode", "Show", 0, "Used / Max", "Percent")).common();
        new Mod("tps", "TPS", "Server ticks per second (estimated).", Cat.INFO, false, true, 0.80f, 0.09f).common();
        new Mod("ping", "Ping", "Your latency to the server.", Cat.INFO, true, true, 0.80f, 0.02f).common();
        new Mod("day", "Day Counter", "How many days the world has run.", Cat.INFO, false, true, 0.01f, 0.30f).common();
        new Mod("speed", "Speed", "How fast you are moving.", Cat.INFO, false, true, 0.80f, 0.23f)
                .opt(Opt.choice("unit", "Unit", 0, "Blocks/s", "km/h"))
                .opt(Opt.bool("vertical", "Include up/down", false)).common();

        // ---------------------------------------------------------------- pvp
        new Mod("cps", "CPS Counter", "Left and right click CPS.", Cat.PVP, true, true, 0.01f, 0.45f)
                .opt(Opt.choice("mode", "Show", 0, "Both", "Left", "Right")).common();
        new Mod("combo", "Combo Counter", "Consecutive hits without being hit.", Cat.PVP, true, true, 0.01f, 0.52f)
                .opt(Opt.integer("timeout", "Reset after (sec)", 1, 10, 1, 3)).common();
        new Mod("reach", "Reach Display", "Distance of your last hit.", Cat.PVP, true, true, 0.01f, 0.59f)
                .opt(Opt.integer("decimals", "Decimals", 1, 3, 1, 2)).common();
        new Mod("keystrokes", "Keystrokes", "WASD, Space, Shift and mouse buttons.", Cat.PVP, true, true, 0.86f, 0.60f)
                .opt(Opt.bool("mouse", "Mouse buttons", true))
                .opt(Opt.bool("space", "Space bar", true))
                .opt(Opt.bool("shift", "Shift", true))
                .opt(Opt.color("color", "Text color", 1))
                .opt(Opt.bool("bg", "Background", true))
                .opt(Opt.choice("bgColor", "Background color", 0, Palette.BG_NAMES))
                .opt(Opt.integer("bgAlpha", "Background opacity", 5, 100, 5, 60));

        // ---------------------------------------------------------------- visuals
        new Mod("motion_blur", "Motion Blur", "Smooth blur while you move and turn.", Cat.VISUALS, false, false, 0, 0)
                .opt(Opt.integer("strength", "Strength (%)", 5, 95, 5, 50))
                .opt(Opt.integer("fps", "Your usual FPS", 30, 240, 10, 60));

        // ---------------------------------------------------------------- tags
        String[] modes = new String[GameMode.values().length + 1];
        modes[0] = "Best";
        for (int i = 0; i < GameMode.values().length; i++) modes[i + 1] = GameMode.values()[i].display;
        new Mod("cctiers_tag", "CcTiers Tag", "CcTiers logo and tier next to player nametags.", Cat.TAGS, true, false, 0, 0)
                .opt(Opt.choice("pos", "Position", 0, "Left", "Right"))
                .opt(Opt.bool("logo", "Show logo", true))
                .opt(Opt.bool("tier", "Show tier", true))
                .opt(Opt.choice("mode", "Gamemode", 0, modes))
                .opt(Opt.bool("own", "Show on myself", true))
                .opt(Opt.bool("tab", "Show in tab list", true));
    }
}
